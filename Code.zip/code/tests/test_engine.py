"""
Automated Regression and Security Test Suite
Ghost Data Still Exists Benchmark
"""

import csv
import json
import os
import sqlite3
import sys
import unittest

# Ensure code is on sys.path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
CODE_DIR = os.path.join(PROJECT_ROOT, "code")
if CODE_DIR not in sys.path:
    sys.path.insert(0, CODE_DIR)

from main import (
    DeletionAuditEngine,
    _is_safe_path,
    _sqlite_security_authorizer,
    RE_TABLE_IDENTIFIER,
    PHASE_ORDER,
)


class TestDeletionAuditEngine(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dataset_dir = os.path.join(PROJECT_ROOT, "dataset")
        cls.engine = DeletionAuditEngine(cls.dataset_dir)

    def test_01_safe_path_boundary(self):
        """Test directory traversal prevention."""
        base = os.path.abspath("dataset")
        safe_child = os.path.join(base, "evidence", "databases", "test.sql")
        unsafe_traversal = os.path.join(base, "..", "passwords.txt")
        self.assertTrue(_is_safe_path(base, safe_child))
        self.assertFalse(_is_safe_path(base, unsafe_traversal))

    def test_02_sqlite_security_authorizer(self):
        """Verify SQLite authorizer strictly denies dangerous commands (ATTACH, DETACH)."""
        conn = sqlite3.connect(":memory:")
        conn.set_authorizer(_sqlite_security_authorizer)
        cur = conn.cursor()
        
        # Safe table creation and selection must work
        cur.execute("CREATE TABLE safe_test (id INT, name TEXT)")
        cur.execute("INSERT INTO safe_test VALUES (1, 'alice')")
        cur.execute("SELECT * FROM safe_test")
        rows = cur.fetchall()
        self.assertEqual(len(rows), 1)

        # ATTACH must be denied by authorizer
        with self.assertRaises(sqlite3.DatabaseError):
            cur.execute("ATTACH DATABASE ':memory:' AS attached_db")
        conn.close()

    def test_03_table_identifier_regex(self):
        """Ensure malicious table names with SQL injection are flagged."""
        self.assertTrue(bool(RE_TABLE_IDENTIFIER.match("customer_data_primary")))
        self.assertTrue(bool(RE_TABLE_IDENTIFIER.match("table_123")))
        self.assertFalse(bool(RE_TABLE_IDENTIFIER.match("table; DROP TABLE users;--")))
        self.assertFalse(bool(RE_TABLE_IDENTIFIER.match("table\" OR 1=1--")))

    def test_04_identity_resolution(self):
        """Verify user resolution across current snapshot and historical audit log."""
        # Current email lookup
        uid, terms = self.engine.resolve_user("elena.romero88@outlook.com")
        self.assertEqual(uid, "user_54")
        self.assertIn("elena.romero88@outlook.com", terms)

        # Historical email resolution (if applicable)
        for hist_email, expected_uid in list(self.engine.hist_email_to_uid.items())[:3]:
            resolved_uid, terms = self.engine.resolve_user(hist_email)
            self.assertEqual(resolved_uid, expected_uid)
            self.assertIn(hist_email, terms)

    def test_05_non_deletion_classification(self):
        """Verify non-deletion requests are correctly classified as NOT_APPLICABLE with empty steps."""
        case_non_del = {
            "case_id": "test_case_nd",
            "email": "test@example.com",
            "requested_at": "2026-09-01T12:00:00Z",
            "reported_status": "COMPLETE",
            "reported_at": "2026-09-01T13:00:00Z",
            "audit_at": "2026-09-01T14:00:00Z",
            "request_text": "Please leave the account active and do not close the account, just update my address."
        }
        status, steps = self.engine.audit_case(case_non_del)
        self.assertEqual(status, "NOT_APPLICABLE")
        self.assertEqual(steps, [])

    def test_06_complete_cases_verification_only(self):
        """Verify that COMPLETE cases contain ONLY verification steps with non-empty citations."""
        sample_path = os.path.join(self.dataset_dir, "sample_deletion_requests.csv")
        sample_gt_path = os.path.join(self.dataset_dir, "sample_output.csv")
        
        with open(sample_gt_path, encoding="utf-8") as f:
            gt_statuses = {r["case_id"]: r["deletion_status"] for r in csv.DictReader(f)}

        with open(sample_path, encoding="utf-8") as f:
            for r in csv.DictReader(f):
                cid = r["case_id"]
                status, steps = self.engine.audit_case(r)
                if status == "COMPLETE":
                    for step in steps:
                        self.assertEqual(step["phase"], "VERIFICATION")
                        self.assertTrue(bool(step["evidence_id"]), f"COMPLETE case {cid} missing evidence citation")

    def test_07_step_phase_ordering_and_numbering(self):
        """Verify consecutive step numbers and FINDING -> REMEDIATION -> VERIFICATION phase progression."""
        sample_path = os.path.join(self.dataset_dir, "sample_deletion_requests.csv")
        with open(sample_path, encoding="utf-8") as f:
            for r in csv.DictReader(f):
                cid = r["case_id"]
                status, steps = self.engine.audit_case(r)
                last_phase_val = 0
                for idx, step in enumerate(steps, start=1):
                    self.assertEqual(step["step_no"], idx, f"Non-consecutive step_no in {cid}")
                    cur_phase_val = PHASE_ORDER[step["phase"]]
                    self.assertGreaterEqual(cur_phase_val, last_phase_val, f"Phase ordering violated in {cid}")
                    last_phase_val = cur_phase_val

    def test_08_output_csv_structure(self):
        """Verify output.csv has exact headers and exactly 518 valid data rows."""
        output_path = os.path.join(PROJECT_ROOT, "output.csv")
        self.assertTrue(os.path.exists(output_path), "output.csv missing at root")
        
        with open(output_path, encoding="utf-8") as f:
            reader = list(csv.reader(f))
            header = reader[0]
            rows = reader[1:]

        self.assertEqual(header, ["case_id", "deletion_status", "steps_json"])
        self.assertEqual(len(rows), 518)

        # Check sorting: case_33 to case_550
        self.assertEqual(rows[0][0], "case_33")
        self.assertEqual(rows[-1][0], "case_550")

    def test_09_evidence_term_indexing(self):
        """Verify that pre-indexed evidence lookups match on terms and resource IDs."""
        self.assertGreater(len(self.engine.all_records_by_term), 100)
        self.assertGreater(len(self.engine.evidence_by_term), 50)
        # Verify user_54 indexing exists
        self.assertIn("user_54", self.engine.all_records_by_term)

    def test_10_sqlite_pragma_security(self):
        """Verify authorizer permits benign PRAGMAs while strictly denying unauthorized ones."""
        conn = sqlite3.connect(":memory:")
        conn.set_authorizer(_sqlite_security_authorizer)
        cur = conn.cursor()
        
        # Benign schema introspection should succeed
        cur.execute("CREATE TABLE pragma_test (col INT)")
        cur.execute("PRAGMA table_info('pragma_test')")
        self.assertEqual(len(cur.fetchall()), 1)
        
        # Benign foreign_keys configuration should succeed
        cur.execute("PRAGMA foreign_keys = ON")

        # Dangerous or unauthorized PRAGMAs must be denied
        with self.assertRaises(sqlite3.DatabaseError):
            cur.execute("PRAGMA query_only = 0")
        conn.close()

    def test_11_audit_time_cutoff_compliance(self):
        """Verify that evidence with captured_at > audit_at is never cited."""
        sample_path = os.path.join(self.dataset_dir, "sample_deletion_requests.csv")
        with open(sample_path, encoding="utf-8") as f:
            for r in csv.DictReader(f):
                audit_at = r["audit_at"]
                status, steps = self.engine.audit_case(r)
                for step in steps:
                    ev_id = step.get("evidence_id")
                    if ev_id:
                        ev_info = self.engine.manifest.get(ev_id)
                        if ev_info:
                            self.assertLessEqual(
                                ev_info["captured_at"],
                                audit_at,
                                f"Case {r['case_id']} cited evidence {ev_id} after audit_at"
                            )


if __name__ == "__main__":
    unittest.main()
