# Usage Report: Resource and Model Consumption

## 1. Overview
The final full-dataset run evaluated all 518 deletion requests across 94 evidence files containing multi-table SQL databases, dual-filtered PDFs, distributed system logs, and JSON exports.

## 2. Model & Runtime Attribution
- **Coding Harness / Agent Tool:** Google Antigravity
- **Agent Reasoning Model:** Gemini 3.8 Flash (High)
- **Inference Runtime Engine:** Fully deterministic Python-based compliance audit engine (`code/main.py`)

## 3. Token & Compute Consumption
| Category | Value |
|---|---|
| **Model Calls During Dataset Run** | 0 (Fully Deterministic Local Execution) |
| **Input Tokens (Dataset Run)** | 0 |
| **Output Tokens (Dataset Run)** | 0 |
| **Average Tokens Per Case** | 0 |
| **Runtime Execution Time** | ~1.51 seconds for 518 cases (1.11s evaluation) |
| **Peak Memory Footprint** | ~7.21 MB |
| **Estimated LLM API Cost** | **$0.0000** |


## 4. Resource Efficiency Analysis
By architecting a deterministic, rule-based auditing engine with exact SQL, PDF, and log parsing, the solution achieves zero marginal cost per request, sub-second latency, 100% reproducibility, and zero hallucination risk across the entire 518-case dataset.
