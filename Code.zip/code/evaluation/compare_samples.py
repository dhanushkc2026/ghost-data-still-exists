import csv, json, os, sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CODE_DIR = os.path.dirname(SCRIPT_DIR)
BASE_DIR = os.path.dirname(CODE_DIR)

while SCRIPT_DIR in sys.path:
    sys.path.remove(SCRIPT_DIR)
if CODE_DIR not in sys.path:
    sys.path.insert(0, CODE_DIR)

from main import DeletionAuditEngine

def find_dir(name):
    for base in [BASE_DIR, os.getcwd(), os.path.dirname(BASE_DIR)]:
        p = os.path.join(base, name)
        if os.path.isdir(p):
            return p
    return os.path.join(BASE_DIR, name)

DATASET_DIR = find_dir("dataset")
eng = DeletionAuditEngine(DATASET_DIR)

sample_output_path = os.path.join(DATASET_DIR, 'sample_output.csv')
sample_requests_path = os.path.join(DATASET_DIR, 'sample_deletion_requests.csv')

with open(sample_output_path, encoding='utf-8') as f:
    gt = {r['case_id']: r for r in csv.DictReader(f)}
with open(sample_requests_path, encoding='utf-8') as f:
    reqs = {r['case_id']: r for r in csv.DictReader(f)}

report = []
exact_matches = 0
status_matches = 0
tot = len(gt)

for cid in sorted(gt, key=lambda x: int(x.split('_')[1])):
    ps, steps = eng.audit_case(reqs[cid])
    gs = gt[cid]['deletion_status']
    gsteps = json.loads(gt[cid]['steps_json'])
    st_match = (ps == gs)
    if st_match:
        status_matches += 1
    seq_match = st_match and (gsteps == steps)
    if seq_match:
        exact_matches += 1
    report.append(f'{cid}: expected={gs} actual={ps} | steps match={seq_match}')
    if gsteps != steps:
        n = min(len(gsteps), len(steps))
        first = None
        for i in range(n):
            if gsteps[i] != steps[i]:
                first = i
                break
        if first is not None:
            report.append(f'  first diff idx {first}')
            report.append(f'   exp: {gsteps[first]}')
            report.append(f'   act: {steps[first]}')
        elif len(gsteps) != len(steps):
            report.append(f'  len mismatch exp={len(gsteps)} act={len(steps)}')

report.append(f"\n==========================================")
report.append(f"STATUS ACCURACY: {status_matches}/{tot} ({status_matches/tot*100:.1f}%)")
report.append(f"EXACT SEQUENCE MATCH: {exact_matches}/{tot} ({exact_matches/tot*100:.1f}%)")
report.append(f"==========================================")

out_report_path = os.path.join(SCRIPT_DIR, 'mismatch_report.txt')
with open(out_report_path, 'w', encoding='utf-8') as f:
    f.write('\n'.join(report))

print('\n'.join(report))

